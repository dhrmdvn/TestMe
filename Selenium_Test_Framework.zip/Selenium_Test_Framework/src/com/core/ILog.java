package com.core;

import org.apache.log4j.Logger;
import java.io.*;
import java.sql.SQLException;
import java.util.*;

public interface ILog {
	public static org.apache.log4j.Logger log = Logger.getLogger(TestExecution.class);	
	//public void Debug(String str);
	public void info(String str);
	public void debug(String str);
	public void warn(String str);
	public void error(String str);
	public void error(Exception str);
	public void callFailError(String tAction,String tParent,String tObject,String tInput,String strDesc, String strError);
	public void callPassDebug(String tAction,String tParent,String tObject,String tInput,String strDesc);
}
