package com.core;

import java.awt.AWTException;
import java.awt.Desktop;
import java.io.BufferedWriter;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import mx4j.log.Log;

import java.awt.Window;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.xml.DOMConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.apache.log4j.*;

import com.report.IReport;
import com.util.IUtility;

import jxl.Cell;
import jxl.JXLException;
import jxl.LabelCell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;
import jxl.write.Label;
import jxl.write.WritableCell;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;

import com.modules.*;

public class TestExecution implements IExcelReader, IKeyword, IReport, IDBConnection, IConfig, IUtility, ILog {
	
	//Variable Declarations - variables are declared Globally to access from all the methods in this class
	
	public static String suite[][],TestCase[][];

	public static String[] sTestCaseID,sExeFlag,sEnvironment,sModules;

	public static String[] sRQRID;

	public static String[][] tObjectName,tAction,tInputData,objcollection;
	
	public static String sTestcasename,tdmodules;
	
	public static long starttime;
	
	public static boolean fBrowser,TestCaseStatus = true;
	
	public static Keyword_Name kAction;
	
	public static By bProperty;
	
	public static WebDriver driver;
	
	static WebElement element;
	
	public static BufferedWriter output = null;
	public static File file;	
	static String sDateTime, sFilename, sBodyText;
	String screenshotpath,strDesc;
	String TestExecutionTime;
	static String htmlreport;
	
	static int Timeout = 30;
	
	static int iCount = 0; //Testcase 'Y' Counter Variable
	
	static int mCount = 0; // Modules Count
	
	protected static File MasterWorkbook;
	
	protected static File ModuleWorkbook = new File(System.getProperty("user.dir")+ "\\src\\com\\testcase\\Modules.xls");
	
	protected static File TestDataWorkbook = new File(System.getProperty("user.dir")+ "\\src\\com\\testcase\\TestData.xls");
	
	static Workbook w = null;
	
	public static Connection conn = null;
	public static PreparedStatement pstmt1 = null;
	public static ResultSet rset1=null;
	
	public static Sheet sheet,modsheet,objsheet,Tdsheet,csheet,tcsheet;
//*********************************************************************************************************************************	
	public void GetSuite() {
		
		//***Load Testcases configured with 'Y' flag from Master sheet***//
		
		// TODO Auto-generated method stub
		
			info("GetSuite Method Starts....");
			
			MasterWorkbook = new File(System.getProperty("user.dir")+ "\\src\\com\\testcase\\Controller.xls");
			
			//Workbook w = null;		
			
				try{
					w = Workbook.getWorkbook(MasterWorkbook);
					sheet = w.getSheet("Master");	
				}catch(IOException | BiffException e){
					error("Reading Master Sheet :-" +e);
				}
			
				sTestCaseID = new String[sheet.getRows()];
				
				sExeFlag = new String[sheet.getRows()];
				
				sEnvironment = new String[sheet.getRows()];
				
				suite = new String[sheet.getRows()][sheet.getColumns()];
				
				debug("Number of Row in Master Sheet :- " + sheet.getRows());
	            
	            debug("Number of Column in Master Sheet :- " + sheet.getColumns());
	            
			   	for (int j = 0; j < sheet.getColumns(); j++){
				    		
				    		for (int i = 0; i < sheet.getRows(); i++){
				          
				    			Cell cell = sheet.getCell(j, i);
				          
				    			if (cell.getContents()!= null){
				              
				    				suite[i][j]=cell.getContents();
				    			}
				        
				    		}
				      
				    	}
			   	
			   	
			   	//Load Testcase with 'Y' Flag
			   	
			   	for (int k = 1;k<sheet.getRows();k++){
			   		
			   		if(((suite[k][1] !=null) && ((char)suite[k][1].charAt(0)) == 'Y')){
			   			
			   			sTestCaseID[iCount] = suite[k][0];
			   			
			   			sExeFlag[iCount] = suite[k][1];
			   			
			   			sEnvironment[iCount] = suite[k][2];
			   			
			   			debug ("Suite : - Test Case ID : " +sTestCaseID[iCount] +" , Execute : "+sExeFlag[iCount]+" , Test Case Name : "+sTestCaseID[iCount]+" , Test Case Count :"+iCount);
			   		 
			   			iCount = iCount+1;
			   		}
			   	}
			   	
			   	
				
			info("GetSuite() method ends..");
	}
	
	public void GetModules() {
		// TODO Auto-generated method stub
		
		// ***** Loads the Respective Modules to the Testcases are set as 'Y'*****//
		
		
		
		info("GetModules() Method Starts");
	
		try{
			w = Workbook.getWorkbook(MasterWorkbook);
			modsheet = w.getSheet("TestModules");	
		}catch(IOException | BiffException e){
			error("Reading TestModules Sheet :-" +e);
		}
		
		setup();
		
		int cols = modsheet.getColumns();
		sModules = new String[cols];
		
		for(int iLoop = 0;iLoop<iCount;iLoop++){
			 CreateReport(sTestCaseID[iLoop],"ST");
			 CreateTableHeader();
			 long starttime = System.currentTimeMillis();
			int trow = (int) modsheet.findLabelCell(sTestCaseID[iLoop]).getRow();
						
			Cell cell = modsheet.getCell(0,trow);
			
			if(cell.getContents().equals(sTestCaseID[iLoop])){
				sTestcasename = sTestCaseID[iLoop];
				System.out.println(sTestcasename);
				for(int iLoop2 = 1;iLoop2<cols;iLoop2++){
					
					Cell mods = modsheet.getCell(iLoop2,trow);
					
					if(mods.getContents()!=null){
						
						if(mods.getContents()!=""){
							
							sModules[mCount] = mods.getContents();
							
							mCount = mCount+1;
							
						}
					}
				}	
			}
			GetTestCase();	
			mCount = 0;
			long endtime =System.currentTimeMillis();
			long temp = endtime - starttime;
			TestExecutionTime = String.format("%d:%02d:%02d", (temp / (1000 * 60 * 60)) % 24,(temp / (1000 * 60)) % 60, (temp / 1000) % 60);
			CreateTableFooter(iCount);
			CloseReport();
		}
		
		info("GetModules() Method Ends");
	}
	
	public void GetTestCase() {
		// TODO Auto-generated method stub
		//Executes the respective class for the modules listed
		
		info("GetTestCase() Method Starts");
		
		for(int mLoop = 0;mLoop<mCount;mLoop++){
			
			tdmodules = sModules[mLoop];
			
			try{
				
				info("Executing the Package");
				
				ExecuteCase(tdmodules);
			}catch(Exception e){
				
				error("Unable to Execute the Modules");
			}
			
			
			
		}
		
		
		
		
	}
	
	//************************************************************************************************************
	//*** Implementation of IKeyword Interface ***
	//************************************************************************************************************
	public static enum Modules_Name {LOGIN,SearchRQR,CreateRQR,CreateQuote_ExistingRQR,Queue}
	public void ExecuteCase(String tdmodules2) {
		// TODO Auto-generated method stub
		
		Modules_Name modname = Modules_Name.valueOf(tdmodules2);
		
		if (tdmodules2!=null){
			
			switch(modname)
			
			{
			/* Login Modules*/
			case LOGIN:
					
						info("Executing Login Modules");
						
						try {
							Login.loginscenario();
							info("Login Modules Executed");
							
						}catch(Exception e){	
							error("Login Class Not Found and Modules cannot be executed");
							callFailError("","","","","Unexpected Error Occur in SearchRQR Class","Error :-"+e);
						}
						break;
			/*Search RQR*/
			case SearchRQR:
				
						info("Executing Search RQR");
			
						try{
							SearchRQR.TestMethods();
							info("SearchRQR Modules Executed");
						}catch (Exception e){
							error("SearchRQR Class Not Found and Modules cannot be executed");
							callFailError("","","","","Unexpected Error Occur in SearchRQR Class","Error :-"+e);
						}
						break;
			/*Create RQR */
			case CreateRQR:
				
						info("Executing CreateRQR");
						
						try{
							CreateRQR.sRQRCreation();
							info("CreateRQR Modules Executed");
						}catch (Exception e){
							error("CreateRQR Class Not Found and Modules cannot be executed");
							callFailError("","","","","Unexpected Error Occur in CreateRQR Class","Error :-"+e);
						}
						break;
						
			/*CreateQuote*/
			case  CreateQuote_ExistingRQR:			
						
						info("Executing CreateQuote");
						
						try{
							CreateQuote_ExistingRQR.QuoteCreation();
							info("Create Quote Modules Executed");
						}catch(Exception e){
							error("CreateQuote Class Not Found OR Modules cannot be executed");
							callFailError("","","","","Unexpected Error Occur in CreateQuote Class","Error :-"+e);
						}
						
			case Queue:
						info("Executing Queue");
				
						try{
							Queue.QueueScenario();
							info("Queue Modules Executed");
						}catch(Exception e){
							error("Queue Class Not Found OR Queue cannot be executed");
							callFailError("","","","","Unexpected Error Occur in Queue Class","Error :-"+e);
						}
			}
			
			
		}
		
	}

	public String GetData(String inputdata ,String Gdsheetname,int sRowNum) {
		// TODO Auto-generated method stub
		
		info("Get input Data");
		
		info("Fetching Data from Test Data Sheet");
		
		Workbook td = null;
		
		try{
			td = Workbook.getWorkbook(TestDataWorkbook);
			Tdsheet = td.getSheet(Gdsheetname);
			if (inputdata!=null){
				if(inputdata!=""){
					//int tdrow = (int) Tdsheet.findLabelCell(sTestcasename).getRow();
					int tdcol = (int) Tdsheet.findLabelCell(inputdata).getColumn();
					
					Cell tdcell = Tdsheet.getCell(tdcol, sRowNum);
					
					inputdata = tdcell.getContents();
				}
			}
		}catch(Exception e){
			error("Reading TestDATA WorkBook :-" +e);
		}
		
		Tdsheet=null;
		td.close();
		return inputdata;
	}

	public static enum Keyword_Name {LAUNCHED, SET, EXIST,CLICK, SELECT,VERIFYTEXT,DOUBLECLICK,LIST,DESELECT,VERIFYTITLE,OPENPOPUP,CLOSEPOPUP, ALERT, SWITCHFRAME, CLOSEFRAME,VERIFYURL,CLEAR,GETTEXT,VERIFYFONTSIZE,VERIFYFONTFAMILY,ISSELECTED,VERIFYCOMBO,GETSELECTEDTEXT}
	
	public boolean KeywordGenerator(String tObject,String tParent,String tAction,String tInput,String tOuput) {
		// TODO Auto-generated method stub
		// ****** Executes the Module Workflow defined in the Worksheet *******//
		
		tParent = driver.getTitle();
		if(tAction!="ALERT"){
			
			if(tObject.isEmpty()){
				error("Object is not available");
			}else{
				
				info("Loading Object Repository");
				
				ORGenerator(tObject);
			}
		}
				
		Keyword_Name kAction = Keyword_Name.valueOf(tAction);

		if (kAction != null){
		
			switch (kAction)
			{
		
				//-----------------Launched - invoke browser ------------------------------
				case LAUNCHED:
					
					info("Keyword : LAUNCHED Starts..");
					try{
						info("Inside Try block..");							
						
						strDesc = "Browser is displayed and launched";
								
						Pass(tAction,"",tObject,tInput,strDesc);
						
					
					}catch(Exception e){
						
						error("Keyword : LAUNCHED " +e);
						
						Fail(tAction,"",tObject,tInput,strDesc);
						
					}
					
					info("Keyword : LAUNCHED Ends..");
								
				break;

				//-----------------SET - enter value in Edit box ------------------------------
				case SET:
					
				   info("Keyword : SET Starts..");
				   
				   if(tInput!=""){
										
					   try{
													
							element.sendKeys(tInput);
									
							callPassDebug(tAction,"",tObject,tInput,"TextField"  + " : "+ tInput +" is entered");
														
						}catch(NoSuchElementException e) {
							
							callFailError(tAction,"",tObject,tInput,"TextField"  + tObject + " : "+ "is not found, ",tObject + e);
						
						}
				   }
																	
					info("Keyword : SET Ends..");						
					break;
					//----------------- CLEAR - Clears text from Text Input field ------------------------------			
					case CLEAR:
						info("Keyword : CLEAR Starts..");
							
						try{
								
						   element.clear();
										
						   callPassDebug(tAction,"",tObject,tInput,"Clear Field"  + " : "+ tInput +" is entered");
															
						}catch(Throwable e) {
								
							callFailError(tAction,"",tObject,tInput,"Clear Field"  + tObject + " : "+ "is not found, ",tObject + e);
							
						}
						
						info("Keyword : CLEAR Ends..");						
						break;
					//----------------- GETTEXT - Returns text from WebElement ------------------------------			
					case GETTEXT:
						info("Keyword : GETTEXT Starts..");	
						try{
							
							String otext = element.getText();
							
							 callPassDebug(tAction,"",tObject,tInput,"Text Field"  + " : "+ otext +" is entered");
							
						}catch (Throwable e){
							
							callFailError(tAction,"",tObject,tInput,"Text Field"  + tObject + " : "+ "is not found, ",tObject + e);
							
						}
						
						info("Keyword : GETTEXT Ends..");						
						break;
					//----------------- VERIFYFONTFAMILY - Returns text from WebElement ------------------------------			
					case VERIFYFONTFAMILY:
						info("Keyword : VERIFYFONTFAMILY Starts..");						
						info("Keyword : VERIFYFONTFAMILY Ends..");						
						break;
					//----------------- VERIFYFONTSIZE - Returns text from WebElement ------------------------------			
					case VERIFYFONTSIZE:
						info("Keyword : VERIFYFONTSIZE Starts..");						
						info("Keyword : VERIFYFONTSIZE Ends..");						
						break;
					//----------------- ISSELECTED - Returns Radio/Checkbox current state ------------------------------			
					case ISSELECTED:
						info("Keyword : ISSELECTED Starts..");						
						info("Keyword : ISSELECTED Ends..");						
						break;
					//----------------- GETSELECTEDTEXT - Returns selected value of Combo/List ------------------------------			
					case GETSELECTEDTEXT:
						info("Keyword : GETSELECTEDTEXT Starts..");						
						info("Keyword : GETSELECTEDTEXT Ends..");						
						break;
					//----------------- VERIFYCOMBO - Checks value in Combo/List ------------------------------			
					case VERIFYCOMBO:
						info("Keyword : VERIFYCOMBO Starts..");						
						info("Keyword : VERIFYCOMBO Ends..");						
						break;
					//----------------- CLICK - Perform Mouse Click on WebElement ------------------------------			
					case CLICK: 	
					
						try{
																
							element.click();
							
							callPassDebug(tAction,"",tObject,tInput,"Link"  + " : "+ tInput +" is Clicked");
							
						}catch(Exception e){
							
							callFailError(tAction,"",tObject,tInput,"Link"  + tObject + " : "+ "is not found, ",tObject + e);
													
						} 
							
						break;
						
					//-----------------EXIST - To Check Object is displayed ------------------------------
					case EXIST:
						
						info("Keyword : EXIST Starts..");
						
						debug("Input Value : "+tOuput);
						
						if (tOuput.isEmpty()|| tObject.isEmpty()){
						
							callFailError(tAction,"",tObject,tInput, tObject + " : "+ "Either Object Name or Expected parameter is not provided, ",tObject +" Either Object Name or Expected parameter is not provided");
																
							break;
						}
						
						boolean temp = false;
						
						if (tOuput.equalsIgnoreCase("true")== true){
							temp=true;
						}
							
						if (tOuput.equalsIgnoreCase("false")== true){
							temp=false;
						}
																
						try{
							strDesc = tObject  + " : "+ "is displayed, Expected : "+tOuput + " , Actual : " + temp;
							
							callPassDebug(tAction,"",tObject,tInput,strDesc);
							
						}catch(NoSuchElementException e) {
							
							strDesc = tObject  + " : "+ "is not displayed , Expected : "+tOuput + " , Actual : " + temp;
							
							callFailError(tAction,"",tObject,tInput,tObject  + strDesc ,tObject + e);
													
						}
																		
						info("Keyword : EXIST Ends..");						

						break;
						
						//----------------- VERIFYTEXT - Check Text/Label/Caption Displayed ------------------------------
						case VERIFYTEXT:
						
						info("Keyword : VERIFYTEXT Starts..");
						
						debug("Input Value : "+tOuput);
																									
						try{
						
							if (StringCompare(element.getText(),tOuput)) {
								
								strDesc = tObject  + " : "+ element.getText()+ " , " +tOuput +"Text is matched";
															 								
								callPassDebug(tAction,"",tObject,tInput,strDesc);
								
							}
							else{
									
								strDesc = tObject  + " : "+ element.getText()+ " , " +tOuput +"Text is not matched";
								
								callFailError(tAction,"",tObject,tInput,""  + strDesc ,tObject + "Text is not matched");
								
							}
							
						}catch(NoSuchElementException e) {
							
							strDesc = tObject + " : "+ "is not found, ";
													
							callFailError(tAction,"",tObject,tInput,""  + strDesc ,tObject + e);
							
						}
																		
						info("Keyword : VERIFYTEXT Ends..");						

						break;
						
						//----------------- DOUBLECLICK - Perform Mouse Double Click Operation ------------------------------
						case DOUBLECLICK:
						
						info("Keyword : DOUBLECLICK Starts..");
						
						debug("Input Value : "+tOuput);
																									
						try{
													
							Actions builder = new Actions(driver); 
								
							builder.doubleClick(element).build().perform();
							
							strDesc = tObject  + " double click operation is performed";
								
							callPassDebug(tAction,"",tObject,tInput,strDesc);
							
						}catch(NoSuchElementException e) {
							
							strDesc = tObject  + " : "+ "is not displayed";
							
							callFailError(tAction,"",tObject,tInput,""  + strDesc ,tObject + e);
							
						}
																		
						info("Keyword : DOUBLECLICK Ends..");						

						break;
						
						//----------------- SELECCT - To Select Single Radio/Checkbox ------------------------------
						case SELECT:
							
							info("Keyword : SELECT Starts..");
							
							debug("Input Value : "+tInput);
																										
							try{
															
								if (!element.isSelected()){
									
									element.click();
									
									strDesc = tObject  + " : is selected";								
																	
									callPassDebug(tAction,"",tObject,tInput,strDesc);								
									
								}
														
							}catch(NoSuchElementException e) {
								
								strDesc = tObject  + " : "+ "is not displayed";
											
								callFailError(tAction,"",tObject,tInput,""  + strDesc ,tObject + e);
								
							}
																			
							info("Keyword : SELECT Ends..");						

							break;
						
						//----------------- DESELECT - To Deselect Single Radio/Checkbox ------------------------------
						case DESELECT:
							
							info("Keyword : DESELECT Starts..");
							
							debug("Input Value : "+tInput);
																										
							try{
																
								if (element.isSelected()){
									
									element.click();
									
									strDesc = tObject  + " : is deselected";
									
									callPassDebug(tAction,"",tObject,tInput,strDesc);	
									
								}
								
							}catch(NoSuchElementException e) {
								
								strDesc = tObject  + " : "+ "is not displayed";
														
								callFailError(tAction,"",tObject,tInput,""  + strDesc ,tObject + e);
								
							}
																			
							info("Keyword : DESELECT Ends..");						

							break;
						//----------------- LIST - To Select Value in Combo Box/List ------------------------------
						case LIST:
							
							if(tInput!=""){
							
								info("Keyword : LIST Starts..");
								
								debug("Input Value : "+tInput);
								
								if(tInput!=null){
																											
									try{
										element = driver.findElement(bProperty);
																					
										if (isObjectDisplayed() == true){
											
										Select make = new Select(element);
										
										make.selectByVisibleText(tInput);
										
										driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
										
												strDesc = tObject  + " : "+ tInput + " is selected";
											
												callPassDebug(tAction,"",tObject,tInput,strDesc);
												
											}
											else{
												
												strDesc = tObject  + " : "+ tInput + " is not selected";
												
												callFailError(tAction,"",tObject,tInput,""  + strDesc ,tObject + strDesc);
											}
									}catch(NoSuchElementException e) {
										
										strDesc = tObject  + " : "+ "is not displayed";
										
										Fail(tAction,"",tObject,tOuput,strDesc);
										
										error(tObject +" is not displayed");
										
									}
								}
							}
							info("Keyword : LIST Ends..");						

							break;
						//----------------- OPENPOPUP - To Open Child/Pop up/ Second Window ------------------------------
						case OPENPOPUP:
							info("Keyword : OPENPOPUP Starts..");						
							
							// TO DO
							
							info("Keyword : OPENPOPUP Ends..");						

							break;  
						
						//----------------- CLOSEPOPUP - To Close Child/Pop up/ Second Window ------------------------------
						case CLOSEPOPUP:
							info("Keyword : OPENPOPUP Starts..");						
							
							// TO DO
							
							info("Keyword : OPENPOPUP Ends..");						

							break;
							
						//----------------- VERIFYTITLE - To Verify Title of Browser ------------------------------
						case VERIFYTITLE:
							info("Keyword : VERIFYTITLE Starts..");		
							
							String ltitle = driver.getTitle();
							
							boolean lresult = StringCompare(tOuput,ltitle);
							
							if (lresult) {
							
								strDesc = tObject  + " : Expected Title : "+ tOuput +" Actual Title : "+  ltitle + " is matched";
														
								callPassDebug(tAction,"",tObject,tInput,strDesc);
							
							}else {
							
								strDesc = tObject  + " : Expected Title : "+ tOuput +" Actual Title : "+  ltitle +  " is not matched";
																						
								callFailError(tAction,"",tObject,tInput,""  + strDesc ,strDesc);
								
							}
													
							info("Keyword : VERIFYTITLE Ends..");						

							break;
							//----------------- VERIFYTITLE - To Verify Title of Browser ------------------------------
						case VERIFYURL:
							
							info("Keyword : VERIFYURL Starts..");	
							
							String turl = driver.getCurrentUrl();
							
							boolean strresult = StringCompare(tOuput,turl);
							
							if (strresult) {
								
								strDesc = tObject  + " : Expected URL: "+ tOuput +" Actual URL: "+  turl + " is matched";
															
								callPassDebug(tAction,"",tObject,tInput,strDesc);
							
							}else {
								
								strDesc = tObject  + " : Expected URL: "+ tOuput +" Actual URL: "+  turl +  " is not matched";
								
								callFailError(tAction,"",tObject,tInput,tObject  + strDesc ,tObject + strDesc);
								
							}
														
							info("Keyword : VERIFYURL Ends..");						

							break;
						//----------------- ALERT - To VERIFY Title & Close ALERT ------------------------------
						case ALERT:
							info("Keyword : OPENPOPUP Starts..");						
							// TO DO
							try{
								
								Robot var = new Robot();
								var.keyPress(KeyEvent.VK_TAB);
								var.keyPress(KeyEvent.VK_TAB);
								var.keyPress(KeyEvent.VK_TAB);
								Thread.sleep(3000);
								var.keyPress(KeyEvent.VK_ENTER);

							}catch(IllegalArgumentException | AWTException | InterruptedException e){
								error("Unable to Perform action on a window");
							}
							
							
							
							
							info("Keyword : OPENPOPUP Ends..");						

							break;
						//----------------- SWITCHFRAME - To Set On IFrame ------------------------------
						case SWITCHFRAME:
							info("Keyword : SWITCHFRAME Starts..");						
							
							// TO DO
							
							info("Keyword : SWITCHFRAME Ends..");						

							break;
						//----------------- CLOSEFRAME - To Close IFrame ------------------------------
						case CLOSEFRAME:
							info("Keyword : CLOSEFRAME Starts..");						
							
							// TO DO
							
							info("Keyword : CLOSEFRAME Ends..");						

							break;
							
						//----------------- some text------------------------------
						default:
							strDesc = tAction +" keyword not found";
																			
							callFailError(tAction,"",tObject,tInput,tObject  + strDesc ,strDesc);
													
							break; 
			
			}// Closing the switch
		}else {
		
			error("Keyword field is blank");
		
		}// closing if 
		
		debug("Test Case Status :- "+TestCaseStatus);
		
		return TestCaseStatus;
	}
	
	//************************************************************************************************************
	//***Returns the Reference of WebElement ***
	//************************************************************************************************************
	
	
	public void ORGenerator(String tObject) {
		// TODO Auto-generated method stub
		
		info("Method ORGenerator Starts..");

		try {
			
			String temp1 = null;

			String tPropertyType = null, tPropertyvalue = null;
		
			FileInputStream objfile_prop = null;
			File objfile = new File(System.getProperty("user.dir")+"\\"+"src"+"\\"+"Object"+"\\"+"Object.properties");
			
			 try {
				 objfile_prop = new FileInputStream(objfile);
					
				} catch (FileNotFoundException e) {
					
					e.printStackTrace();
					info("Intializing Properties File");
					
				}		
			 
			  Properties obj_prop = new Properties();
			  try {
				  
				  obj_prop.load(objfile_prop);
					
				} catch (IOException e) {
					
					e.printStackTrace();
					info("Loading Properties File");
				}
			  
			//Read object property from Object Property File
			  
			  temp1 = obj_prop.getProperty(tObject);
			  String [] temp2 = temp1.split(";");
			  
			  tPropertyType = temp2[0];
			  
			  tPropertyvalue = temp2[1];
			  
				debug("Property Name: -" + tPropertyType +"Property value: -" +tPropertyvalue);
			
		
		//Assigning values to appropriate locator & returning reference to bProperty variable
				if (tPropertyType.equalsIgnoreCase("css")){
					
					bProperty = By.cssSelector(tPropertyvalue);
				}
				
				else if(tPropertyType.equalsIgnoreCase("id")){
				
					bProperty = By.id(tPropertyvalue);
				}
				
				else if(tPropertyType.equalsIgnoreCase("linkText")){
				
					bProperty = By.linkText(tPropertyvalue);
				}
				
				else if(tPropertyType.equalsIgnoreCase("name")){
				
					bProperty = By.name(tPropertyvalue);
					
				}
				
				else if(tPropertyType.equalsIgnoreCase("partialLinkText")){
				
					bProperty = By.partialLinkText(tPropertyvalue);
					
				}
				
				else if(tPropertyType.equalsIgnoreCase("tagName")){
				
					bProperty = By.tagName(tPropertyvalue);
				}
				
				else if(tPropertyType.equalsIgnoreCase("xpath")){
				
					bProperty = By.xpath(tPropertyvalue);
				}
				
				else if(tPropertyType.equalsIgnoreCase("link")){
				
					bProperty = By.linkText(tPropertyvalue);
				}
				
				element = driver.findElement(bProperty);
				
				if ((isObjectDisplayed() == true) || (isObjectEnabled() == true)){			
					
					info(tObject + " is displayed");

				}

				else{
												
					error(tObject +" is not displayed");
					
					Fail("","","","",tObject + " is not displayed");
				}  
				
		}catch(Exception e){
			
			  error("ORGenerator Method .. "+e);
			  
		  }
		info("ORGenerator Method Ends.."); 
		
	}
	
	public void info(String str) {
		// TODO Auto-generated method stub
		log.info("Info : "+ str);
	}

	
	public void warn(String str) {
		// TODO Auto-generated method stub
		log.warn("Warning :-"+str);
		
	}

	
	public void error(String str) {
		// TODO Auto-generated method stub
		log.error("Error:-"+str);
	}

	
	public void error(Exception str) {
		// TODO Auto-generated method stub
		log.error("Exception:-"+str);
	}

	
	public void callFailError(String tAction, String tParent, String tObject,
			String tInput, String strDesc, String strError) {
		// TODO Auto-generated method stub
		
		error("Keyword : "+ tAction+ " : " +strError);
		
		Fail(tAction,tParent,tObject,tInput,strDesc);
		
	}

	
	public void callPassDebug(String tAction,String tParent,String tObject,String tInput,String strDesc) {
		// TODO Auto-generated method stub
		debug("Keyword : "+ tAction+ " : Browser :" + driver.getTitle() + "Object :" + tObject + "Input :" +  tInput+ " , "+strDesc);
		
		Pass(tAction,driver.getTitle(),tObject,tInput,strDesc);
	}

	
	public void setup() {
		// TODO Auto-generated method stub
		launchBrowser();
	}

	
	public void tearDown() {
		// TODO Auto-generated method stub
		try {
			
				driver.quit();
		}
		catch(NoSuchElementException e)
		{
			driver.quit();
		}
	}

	
	public boolean isObjectEnabled() {
		// TODO Auto-generated method stub
		info("isObjectEnabled() Method Starts..");
		
		boolean exist = false;
		
		try {
			for (int second = 0; second<Timeout; second++) {
			
				driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
				
				if (element.isEnabled()){
			
					exist =true;
					
					break;
				} 
		 
			}
		}catch (NoSuchElementException e){
			
			error(e);
			
			exist =false;
		}

		info("isObjectEnabled() Method Ends..");
		
		return exist;
	}

	
	public boolean isObjectDisplayed() {
		// TODO Auto-generated method stub
		info("isObjectDisplayed() Method Starts..");
		
		boolean exist = false;
		try {
			for (int second = 0; second<Timeout; second++) {
			
				driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
				
				if (element.isDisplayed()){
			
					exist =true;
					
					break;
				} 
		 
			}
		}catch (NoSuchElementException e){
			error(e);
			exist =false;
		}

		info("isObjectDisplayed() Method Ends..");
		
		return exist;
	}

	
	public String GetTime() {
		// TODO Auto-generated method stub
		SimpleDateFormat sdfTime = new SimpleDateFormat("HH:mm:ss");
		
		Date now = new Date();

		String strTime = sdfTime.format(now);
		
		return strTime;
	}

	
	public String GetDate() {
		// TODO Auto-generated method stub
		SimpleDateFormat sdfDate = new SimpleDateFormat("dd-MM-yyyy");
		
		Date now = new Date();

		String strDate = sdfDate.format(now);
		
		strDate = strDate.replace("-", "/");
		
		return strDate;
	}

	
	public boolean StringCompare(String fromApp, String tOutput){
		
		boolean temp = false;
		
		if (fromApp.equals(tOutput)) {
		
			temp= true;
		
		}
		else{
		
			temp =false;
			
		}
		
		return temp;
	}

	
	public void launchBrowser() {
		// TODO Auto-generated method stub
		
		//driver = new FirefoxDriver();
		System.setProperty("webdriver.ie.driver","C:\\Users\\h.soundrajan\\Desktop\\Selenium-works-WIP\\Selenium_Test_Framework\\IEDriverServer.exe");
		driver = new InternetExplorerDriver();
		
		
		//driver.manage().window().maximize();
		
		if (suite[1][2].equals("ST")){

		//driver.get("http://xnzauwa10x.nndc.kp.org:9061/kp_webapp/login.do");
			//driver.get("http://xczauwa6x.crdc.kp.org:9061/kp_webapp");
			driver.get("http://xnzadwa3x.nndc.kp.org:9061/kp_webapp/login.do");
		
		}
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
	}

	public Connection CreateConnection(String DBUsername,String DBPassword,String DBServer) throws ClassNotFoundException, SQLException {
		
		try {
			Class.forName("com.ibm.db2.jcc.DB2Driver");
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("Please include Classpath Where your DB2 Driver is located");
			e.printStackTrace();
		}
			
		//String USER_ID = "Y183111";
		//String PWD = "Hpnithin@3010";
		//String dburl = "jdbc:db2://npsuatruw.crdc.kp.org:60001/NPISQRUW";
		
		try{
			conn = DriverManager.getConnection(DBServer,DBUsername,DBPassword);
		}catch(Exception e){
			e.printStackTrace();
		}
		return conn;
	}

	
	public String GetDBValue(String query, String ReturnColumnName)
			throws IOException, ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	
	public void GetDateTime() {
		// TODO Auto-generated method stub
		try{
			
			SimpleDateFormat sdfDate = new SimpleDateFormat("dd-MM-yyyy");
		
			SimpleDateFormat sdfTime = new SimpleDateFormat("HH:mm:ss");
		
			Date now = new Date();
		
			String strDate = sdfDate.format(now);
		
			String strTime = sdfTime.format(now);
		
			strTime = strTime.replace(":", "-");
		
			sDateTime = strDate + "_" + strTime;}
		
		catch (Exception e){
			
			error(e);
			} 
	}

	
	public void CreateReport(String sTestCaseID2,String sEnv) {
		// TODO Auto-generated method stub
		
		info("CreateReport Method started");
		
		GetDateTime();

		sFilename = sTestCaseID2+"_"+"Execution_Report_" + sDateTime+ ".html";

		try{
			
			htmlreport =System.getProperty("user.dir") + "\\src\\com\\report\\Runtime_Report" + File.separator + sFilename;
			
			file = new File(htmlreport);
			
			output = new BufferedWriter(new FileWriter(file));

			output.write("<html><body>");

			output.write("<align =middle><h2><font face=Georgia <u>KP-NPS AUTOMATION SUITE RESULTS </u></h2></font>");
			
			output.write("<tr>");

			output.write("<td colspan=6 width=1000 bgcolor=#EFFBF5  align= Left><font face = Georgia size = 2><b>Total TestCase ::   </b></font> <font face = Georgia size=2>" + sTestCaseID2 + "</font></br>");

			output.write("<b>Environment ::   </b></font> <font face = Georgia size=2>" + sEnv + "</font></br>");

			//output.write("Iteration  ::   </font> <font face = Georgia size=2>" + sIteration + "</font></br>");

			output.write("Execution Start Time  ::   </font> <font face = Georgia size=2>" + GetDate() + " " +GetTime() + "</font></br></td>");

			output.write("</tr>");

		}
		catch (Exception e){
			
			error("CreateReport() Method .."+e);
		}
		
		info("CreateReport() method ends..");
		
	}

	
	public void CloseReport() {
		// TODO Auto-generated method stub
		info("CloseReport() method starts..");
		
		try {
			
			output.close();
		} 
		catch (Exception e){
		
			error(e);
		}
		info("CloseReport() method ends..");
	}

	
	public void CreateTableHeader() {
		// TODO Auto-generated method stub
		
		info("CreateTableHeader() method starts..");
		
		GetDateTime();

		try{
			
			output.write("<table cellpadding=0 cellspacing=0 width=1000 border=1 bordercolor=BLACK>");

			output.write("<tr>");

			output.write("<td width=150 bgcolor=#0404B4 align=middle><font face=Georgia size=2 color=white><b>Action</b></font></td>");

			output.write("<td width=100 bgcolor=#0404B4 align=middle><font face=Georgia size=2 color=white><b>Page</b></font></td>");

			output.write("<td width=150 bgcolor=#0404B4 align=middle><font face=Georgia size=2 color=white><b>Object</b></font></td>");

			output.write("<td width=150 bgcolor=#0404B4 align=middle><font face=Georgia size=2 color=white><b>Test Data</b></font></td>");

			output.write("<td width=150 bgcolor=#0404B4 align=middle><font face=Georgia size=2 color=white><b>Verification</b></font></td>");

			output.write("<td width=150 bgcolor=#0404B4 align=middle><font face=Georgia size=2 color=white><b>Result</b></font></td>");

			output.write("</tr>");
			

		}
		catch (Exception e){
		
			error("CreateTableHeader() - Inside Exception.. "+ e);
		}
		info("CreateTableHeader() method ends..");
		
		
	}

	
	public void CreateTableFooter(int sIteration) {
		// TODO Auto-generated method stub
		info("CreateTableFooter() method starts..");
		
		debug("Iteration : "+sIteration);
		GetDateTime();

		try{

			output.write("<tr>");

			output.write("<td colspan=6 width=1000 bgcolor=#EFFBF5  align= Left><font face = Georgia size = 2>Iteration</b></font> <font face = Georgia size=2>" + sIteration + " Execution Completed </font></br>");

			output.write("<b>Exeuction Time ::   </b></font> <font face = Georgia size=2>" + ((TestExecutionTime)) + "</font></br>");

			output.write("Execution completed at  ::   </font> <font face = Georgia size=2>"  + GetDate() + " " +GetTime() + "</font></td>");

			output.write("</tr>");

		}
		catch (Exception e){
			
			error(e);
		}

	info("CreateTableFooter() method ends..");
	}

	
	public void Pass(String sAction, String sWindow, String sObject, String sTestData, String sVerificationStep) {
		// TODO Auto-generated method stub
		info("Pass method starts..");
		
		debug (sAction+","+ sWindow+","+sObject+","+sTestData+","+sVerificationStep);
		
		try{
			output.write("<tr>");
		
			output.write("<td width=100 bgcolor=#EFFBF5  align=left><font face=Georgia size=2 color=black>" + sAction + "</font></td>");
		
			output.write("<td width=100 bgcolor=#EFFBF5  align=left><font face=Georgia size=2 color=black>" + sWindow + "</font></td>");
		
			output.write("<td width=150 bgcolor=#EFFBF5  align=left><font face=Georgia size=2 color=black>" + sObject + "</font></td>");
		
			output.write("<td width=100 bgcolor=#EFFBF5  align=left><font face=Georgia size=2 color=black>" + sTestData + "</font></td>");
		
			output.write("<td width=400 bgcolor=#EFFBF5  align=left><font face=Georgia size=2 color=black>" + sVerificationStep + "</font></td>");
		
			output.write("<td width=100 bgcolor=#EFFBF5  align=left><font face=Georgia size=2 color=green><b>PASS</b></font></td>");
		
			output.write("</tr>");
			
		}catch (Exception e){
			
			debug("Pass method -- Inside Exception");
				
			error(e);
		}
		
		info("Pass method ends..");	
		
		
		
		
		
	}

	
	public void Fail( String sAction, String sWindow, String sObject, String sTestData, String sVerificationStep) {
		// TODO Auto-generated method stub
		info("Fail method starts..");
		
		debug (sAction+","+ sWindow+","+sObject+","+sTestData+","+sVerificationStep);
		
		String error = Snap_Shots(driver);
		
		try{output.write("<tr>");

		output.write("<td width=100 bgcolor=#EFFBF5  align=left><font face=Georgia size=2 color=red>" + sAction + "</font></td>");

		output.write("<td width=100 bgcolor=#EFFBF5  align=left><font face=Georgia size=2 color=red>" + sWindow + "</font></td>");

		output.write("<td width=150 bgcolor=#EFFBF5  align=left><font face=Georgia size=2 color=red>" + sObject + "</font></td>");

		output.write("<td width=100 bgcolor=#EFFBF5  align=left><font face=Georgia size=2 color=red>" + sTestData + "</font></td>");

		output.write("<td width=400 bgcolor=#EFFBF5  align=left><font face=Georgia size=2 color=red>" + sVerificationStep +"<a href="+error+">"+" Click to Open Screenshot of Error</a></font></td>");
				
		output.write("<td width=100 bgcolor=#EFFBF5  align=left><font face=Georgia size=2 color=red><b>FAIL !</b></font></td>");

		output.write("</tr>");}

		catch (Exception e){System.err.println(e);}
		
		info("Fail method ends..");	
	}

	
	public String Snap_Shots(WebDriver driver) {
		// TODO Auto-generated method stub
		info("SnapShots method starts..");
		
		File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		GetDateTime();

		screenshotpath = System.getProperty("user.dir")+ "\\src\\com\\report\\Error\\" + sDateTime+ ".png";
		
		try {
	   
			FileUtils.copyFile(scrFile, new File(screenshotpath));
	
		} catch (IOException e) {
	
	
			e.printStackTrace();
	}
	info("Snap_Shots method ends..");

	return screenshotpath;

	}

	
	public void openReport() {
		// TODO Auto-generated method stub
		if (Desktop.isDesktopSupported()) {
	        try {
	        	
	            File htmlfile = new File(htmlreport);
	            
	            Desktop.getDesktop().open(htmlfile);
	            
	            
	        } catch (IOException ex) {
	            
	        	System.out.println("Error opening a html page.");
	            
	            ex.printStackTrace();
	        }
	    }
	}
	
	public void debug(String str) {
		// TODO Auto-generated method stub
		log.debug("debug:-"+str);
	}

	public void startExecution() {
		// TODO Auto-generated method stub
		GetSuite();
		
		GetModules();
	}

	public void ClickTableprop(int sRowid){
		
		driver.findElement(By.xpath("/html/body/table[3]/tbody/tr/td[1]/form/table[3]/tbody/tr[1]/td[1]/table/tbody/tr/td["+sRowid+"]/a")).click();			
		
	}
	
	public String Getelementval(String Elememtprop){
		
		String [] telementval = driver.findElement(By.name(Elememtprop)).getText().split(";");
		
		if (telementval[0]=="xpath"){
			return driver.findElement(By.xpath(telementval[1])).getText();
		}
		
		if(telementval[0]=="name"){
			return driver.findElement(By.name(telementval[1])).getText();
		}else{
			return null;
		}
				
	}
	
	public int GETsTC_Count(String sheetname){
		int counter = 0;
		Workbook tc = null;
		
		try{
			tc = Workbook.getWorkbook(TestDataWorkbook);
			csheet = tc.getSheet(sheetname);

			int fTCrow = GetROWID(sheetname);
			for(int i = fTCrow;i<csheet.getRows();i++){
				Cell cell = csheet.getCell(0,i);
				if(cell.getContents().equals(sTestcasename)){
					counter = counter+1;
				}
			}
		}catch(IOException | BiffException e){
			error("Unable Reading TestDATA WorkBook :-" +e);
		}
		tc.close();
		return counter;
	}
	
	public int GetROWID(String strSheetnames){
		
		Workbook rt = null;
		int fTC_rowid = 0;
		try{
			rt = Workbook.getWorkbook(TestDataWorkbook);
			Sheet rtsheet = rt.getSheet(strSheetnames);
			
			 fTC_rowid = (int) rtsheet.findLabelCell(sTestcasename).getRow();
		}catch(IOException | JXLException e){
			error("Unable Get Row ID from TestDATA WorkBook :-" +e);
		}
		
		rt.close();
		return fTC_rowid;
		
	}
	
	public void ClickElement(String val){
		
		driver.findElement(By.linkText(val));
	}
	public int GETCountwithFlag(String sheetsnames,int Flagval){
		
		int counters = 0;
		Workbook tcs = null;
		
		try{
			tcs = Workbook.getWorkbook(TestDataWorkbook);
			tcsheet = tcs.getSheet(sheetsnames);

			int fTCrow = GetROWID(sheetsnames);
			for(int i = fTCrow;i<tcsheet.getRows();i++){
				Cell cell = tcsheet.getCell(0,i);
				if(cell.getContents().equals(sTestcasename)){
					Cell strcell = tcsheet.getCell(1,i);
					int dx = Integer.parseInt(strcell.getContents());
					if(dx == Flagval){
						counters = counters+1;
					}
				}
			}
		}catch(IOException | BiffException |NumberFormatException e){
			error("Unable Reading TestDATA WorkBook :-" +e);
		}
		tcs.close();
		return counters;
	}
	
	public int GetROWId_Flag(String strssheets,int Flagid){
		
		int counters1 = 0;
		Workbook tcs1 = null;
		
		try{
			tcs1 = Workbook.getWorkbook(TestDataWorkbook);
			Sheet tcsheet1 = tcs1.getSheet(strssheets);

			int fTCrow1 = GetROWID(strssheets);
			for(int i1 = fTCrow1;i1<tcsheet1.getRows();i1++){
				Cell cell = tcsheet1.getCell(0,i1);
				if(cell.getContents().equals(sTestcasename)){
					Cell strcell = tcsheet1.getCell(1,i1);
					int dx1 = Integer.parseInt(strcell.getContents());
					if(dx1 == Flagid){
						counters1 = i1;
					}
				}
			}
		}catch(IOException | BiffException |NumberFormatException e){
			error("Unable Reading TestDATA WorkBook :-" +e);
		}
		tcs1.close();
		return counters1;
		
	}
	
	public void WriteDatatoexcel(String strname,String ColNme,int RowIDsNum,String strdata){
		
		File writebook = new File("C:\\Users\\h.soundrajan\\Desktop\\Selenium-works-WIP\\Selenium_Test_Framework\\src\\com\\testcase\\TestData.xls");
		
		try{
			Workbook wrbook = Workbook.getWorkbook(writebook);
			WritableWorkbook testbook = Workbook.createWorkbook(new File(writebook.getAbsolutePath()),wrbook);
			WritableSheet testsheet = testbook.getSheet(strname);
			int ColNum = (int)testsheet.findLabelCell(ColNme).getColumn();
			WritableCell c;
			Label lbl = new Label(ColNum,RowIDsNum,strdata);
			c=(WritableCell) lbl;
			testsheet.addCell(lbl);
			testbook.write();
			testbook.close();
			wrbook.close();
			
		}catch(Exception e){
			//TO-DO code
			e.printStackTrace();
		}
		
	}
	
}
