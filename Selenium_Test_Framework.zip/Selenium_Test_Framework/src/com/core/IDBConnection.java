package com.core;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

public interface IDBConnection {
	public Connection CreateConnection(String DBUsername,String DBPassword,String DBServer) throws ClassNotFoundException, SQLException;
	public String GetDBValue(String query, String ReturnColumnName) throws IOException, ClassNotFoundException, SQLException;
}
