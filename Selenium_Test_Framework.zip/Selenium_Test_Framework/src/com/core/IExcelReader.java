package com.core;

import java.io.IOException;

public interface IExcelReader {
	public void GetSuite();
	public void GetModules();
	//public void GetTestCase();
	public void ORGenerator(String tObject);

}
