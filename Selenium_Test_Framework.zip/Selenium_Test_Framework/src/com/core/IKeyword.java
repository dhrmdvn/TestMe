package com.core;

public interface IKeyword {
	public void ORGenerator(String tObject);	
	public boolean KeywordGenerator(String tObject,String tParent,String tAction,String tInput,String tOuput);
}
