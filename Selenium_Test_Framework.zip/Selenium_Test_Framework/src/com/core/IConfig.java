package com.core;

public interface IConfig {

}
