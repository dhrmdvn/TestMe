package com.modules;

import com.core.*;

public class Inbox {
	
	public static void strInbox(){
		
		TestExecution inb = new TestExecution();
		
		
		
		
		
		
		
	}

}
