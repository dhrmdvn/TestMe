package com.modules;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.core.*;

public class Inbox_MQMBatch {
	
	public static void MQMBatch(){
		
		TestExecution mR = new TestExecution();
		
		mR.sRQRID  = new String[mR.sRQRID.length];
		
		int x = 1;
		
		mR.KeywordGenerator("Inbox","","CLICK","","");
		
		WebElement intbl = mR.driver.findElement(By.id("row"));
		WebElement intb1 = mR.driver.findElement(By.xpath("/html/body/table[3]/tbody/tr/td[1]/table/tbody/tr/td/form/table[4]/tbody/tr/td/table[1]/tbody"));
		List trows = intb1.findElements(By.tagName("tr"));
		
		for(int inb = 0;inb<trows.size();inb++){
			
			
			List tCols = ((WebElement) trows.get(inb)).findElements(By.tagName("td"));
			
			System.out.println(inb);
						
			System.out.println(tCols.size());
			
			System.out.println(((WebElement) tCols.get(8)).getText());
			
			//System.out.println(((WebElement) tCols.get(22)).getText());
			
			for(int arr=0;arr<mR.sRQRID.length;arr++){
				
				if(((WebElement) tCols.get(8)).getText().equals(mR.sRQRID[arr])){
					
					mR.driver.findElement(By.xpath("/html/body/table[3]/tbody/tr/td[1]/table/tbody/tr/td/form/table[4]/tbody/tr/td/table[1]/tbody/tr["+x+"]/td[17]/input")).click();
					
					mR.KeywordGenerator("MQMButton","","CLICK","","");
					
					mR.KeywordGenerator("MQMB","","CLICK","","");
					
				}
				
			}
					
			inb = inb+2;
			
			x = x+1;
			
		}
		
	}
}
