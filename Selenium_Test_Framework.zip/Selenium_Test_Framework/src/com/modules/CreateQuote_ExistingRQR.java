package com.modules;

import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.core.TestExecution;
public class CreateQuote_ExistingRQR {	
	
	public static void QuoteCreation(){
		
		
		TestExecution qR = new TestExecution();
		
		qR.KeywordGenerator("SearchRQR", "", "CLICK","","");
		
		int qRowid = qR.GetROWID("CreateRQR");
		
		String rgns = qR.GetData("CreateQuoteEXR","RatingRegions",qRowid);
		qR.KeywordGenerator("Rating_Rgns","","LIST","","");
		
		
	}
}
