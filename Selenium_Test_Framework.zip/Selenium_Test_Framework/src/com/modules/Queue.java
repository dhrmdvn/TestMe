package com.modules;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.core.TestExecution;

public class Queue {
	
	static String Filter,RQRstatus,RQRType,Group_Num,ServiceArea,RatingRegion,Priority,RQRID,GroupName,EffecDuedatefrom,EffecDuedateTo,ContractID,VersionNo,ExternalRQRID,SalesExecutive;
	
	public static void QueueScenario(){
		
		TestExecution Q = new TestExecution();
		
		//int sCount = Q.GETsTC_Count("Queue");
		int sRowIDTC = Q.GetROWID("Queue");
				
		Filter = Q.GetData("FilterType","Queue",sRowIDTC);
		
		Q.KeywordGenerator("Queue","","CLICK","","");
		
		Q.KeywordGenerator("Queuepage","","VERIFYTEXT","","");
		
		if(Filter.equals("Basic")){
			
			String RQRstatus = Q.GetData("RQRstatus","Queue",sRowIDTC);
			
			Q.KeywordGenerator("qRQRStatus","","LIST",RQRstatus,RQRstatus);
			
			String RQRType = Q.GetData("RQRType","Queue",sRowIDTC);
			
			Q.KeywordGenerator("qRQRType","","LIST",RQRType,RQRType);
			
			String Group_Num = Q.GetData("GroupNo","Queue",sRowIDTC);
			
			Q.KeywordGenerator("Group_Num","","LIST",Group_Num,Group_Num);
			
			String ServiceArea = Q.GetData("ServiceArea","Queue",sRowIDTC);
			
			Q.KeywordGenerator("qServiceArea","","LIST",ServiceArea,ServiceArea);
			
			String RatingRegion = Q.GetData("RatingRegion","Queue",sRowIDTC);
			
			Q.KeywordGenerator("qRatingrgn","","LIST",RatingRegion,RatingRegion);
			
			Q.KeywordGenerator("qFilter","","CLICK","","");
			
			FormQuery();
			
			CheckResult(Q,Q.driver);
		}else{
			
			String RQRstatus = Q.GetData("RQRStatus","Queue",sRowIDTC);
			
			Q.KeywordGenerator("qRQRStatus","","LIST",RQRstatus,RQRstatus);
			
			String RQRType = Q.GetData("RQRType","Queue",sRowIDTC);
			
			Q.KeywordGenerator("qRQRType","","LIST",RQRType,RQRType);
			
			String Group_Num = Q.GetData("GroupNo","Queue",sRowIDTC);
			
			Q.KeywordGenerator("Group_Num","","LIST",Group_Num,Group_Num);
			
			String ServiceArea = Q.GetData("ServiceArea","Queue",sRowIDTC);
			
			Q.KeywordGenerator("qServiceArea","","LIST",ServiceArea,ServiceArea);
			
			String RatingRegion = Q.GetData("RatingRegion","Queue",sRowIDTC);
			
			Q.KeywordGenerator("qRatingrgn","","LIST",RatingRegion,RatingRegion);
			
		    String Priority = Q.GetData("Priority","Queue",sRowIDTC);
			
			Q.KeywordGenerator("qPriority","","LIST",Priority,Priority);
			
			String RQRID = Q.GetData("RQRID","Queue",sRowIDTC);
			
			Q.KeywordGenerator("rqr_id","","SETTEXT",RQRID,RQRID);
			
			String GroupName = Q.GetData("GroupName","Queue",sRowIDTC);
			
			Q.KeywordGenerator("qGrpName","","SETTEXT",GroupName,GroupName);
			
			String SalesExecutive = Q.GetData("SalesExecutive","Queue",sRowIDTC);
			
			Q.KeywordGenerator("qSaleExecutives","","LIST",SalesExecutive,SalesExecutive);
			
			//String StdDueDateFrom = Q.GetData("StdDueDateFrom","Queue",sRowIDTC);
			
			//Q.KeywordGenerator("qStdDuedatefrm","","SETTEXT",StdDueDateFrom,StdDueDateFrom);
			
			//String StdDueDateTo = Q.GetData("StdDueDateTo","Queue",sRowIDTC);
			
			//Q.KeywordGenerator("qStdDuedateto","","SETTEXT",StdDueDateTo,StdDueDateTo);
			
			String EffecDuedatefrom = Q.GetData("EffecDuedatefrom","Queue",sRowIDTC);
			
			Q.KeywordGenerator("qEffrom","","SETTEXT",EffecDuedatefrom,EffecDuedatefrom);
			
			String EffecDuedateTo = Q.GetData("EffecDuedateTo","Queue",sRowIDTC);
			
			Q.KeywordGenerator("qEffto","","SETTEXT",EffecDuedateTo,EffecDuedateTo);
			
			//String SPASLeadID = Q.GetData("SPASLeadID","Queue",sRowIDTC);
			
			//Q.KeywordGenerator("qspasleadid","","SETTEXT",SPASLeadID,SPASLeadID);
			
			//String SPASRQRID = Q.GetData("SPASRQRID","Queue",sRowIDTC);
			
			//Q.KeywordGenerator("qspasRqrid","","SETTEXT",SPASRQRID,SPASRQRID);
			
			//String SPASSetID = Q.GetData("SPASSetID","Queue",sRowIDTC);
			
			//Q.KeywordGenerator("qspassetid","","SETTEXT",SPASSetID,SPASSetID);
			
			String ContractID = Q.GetData("StdDueDateTo","Queue",sRowIDTC);
			
			Q.KeywordGenerator("qContid","","SETTEXT",ContractID,ContractID);
			
			String VersionNo = Q.GetData("VersionNo","Queue",sRowIDTC);
			
			Q.KeywordGenerator("qverno","","SETTEXT",VersionNo,VersionNo);
			
			String ExternalRQRID = Q.GetData("ExternalRQRID","Queue",sRowIDTC);
			
			Q.KeywordGenerator("qExternalRQRid","","SETTEXT",ExternalRQRID,ExternalRQRID);
			
			Q.KeywordGenerator("qFilter","","CLICK","","");
			
			FormQuery();

		}
		
	}

	private static void CheckResult(TestExecution q1, WebDriver driver1) {
		// TODO Auto-generated method stub
		
		String user = q1.GetData("DBUser","LOGIN",1);
		String pass = q1.GetData("DBPass","LOGIN",1);
		String server = q1.GetData("DBServer","LOGIN",1);
		
		
		try {
			q1.CreateConnection(user, pass, server);
			try {
				q1.GetDBValue("query","dbcolname");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			q1.callFailError("Connect","","DataBase","","Unable to Connect to DB","DB Connect Error+e");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			q1.callFailError("Connect","","DataBase","","Unable to reterive data from DB","DB Connect Error+e");
			e.printStackTrace();
		}
		
	}
	
	
	public static String FormQuery(){
		//RQRstatus,RQRType,Group_Num,ServiceArea,RatingRegion,Priority,RQRID,GroupName,EffecDuedatefrom,EffecDuedateTo,ContractID,VersionNo,ExternalRQRID;
		String query  = "Select RQR_ID from ruw.rqr r,group g where r.Current_owner = QUEUE";
		
		if(RQRstatus!=""){
			query = query +"and r.RQR_STATUS_CODE = "+RQRstatus+"";
		}
		if(RQRType!=""){
			query = query +"and r.RQR_TYPE_CODE = "+RQRType+"";
		}
		if(Group_Num!=""){
			query = query +"and g.Group_Num = "+Group_Num+"";
		}
		if(ServiceArea!=""){
			query = query +"and r.Service_area_name = "+ServiceArea+"";	
		}
		if(Priority!=""){
			query = query +"and r.RQR_PRIORITY_CODE = "+Priority+"";	
		}
		if(GroupName!=""){
			query = query +"and g.Group_Name = "+GroupName+"";
		}
		if(RQRID!=""){
			query = query +"and r.RQR_ID = "+RQRID+"";
		}
		if(SalesExecutive!=""){
			query = query +"and r.EXTERNAL_ACCOUNT_EXEC_NAME = "+SalesExecutive+"";
		}
		if(EffecDuedatefrom!=""){
			query = query +"and r.EFF_DATE_FROM = "+EffecDuedatefrom+"";
		}
		if(EffecDuedateTo!=""){
			query = query +"and r.EFF_DATE_TO = "+EffecDuedateTo+"";
		}
		if(VersionNo!=""){
			query = query +"and r.Version = "+VersionNo+"";
		}
		if(ExternalRQRID!=""){
			query = query +"and r.EXTERNAL_RQR_ID = "+ExternalRQRID+"";
		}
		System.out.println(query);
		return query;
	}
		
}
