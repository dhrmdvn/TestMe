package com.modules;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.core.*;

public class Inbox_ForceRates {
	
	public static void ForceRates(){
		
		TestExecution fR = new TestExecution();
		
		
		
		fR.sRQRID  = new String[fR.sRQRID.length];
		
		int x = 1;
		
		fR.KeywordGenerator("Inbox","","CLICK","","");
		
		WebElement intbl = fR.driver.findElement(By.id("row"));
		WebElement intb1 = fR.driver.findElement(By.xpath("/html/body/table[3]/tbody/tr/td[1]/table/tbody/tr/td/form/table[4]/tbody/tr/td/table[1]/tbody"));
		List trows = intb1.findElements(By.tagName("tr"));
		
		for(int inb = 0;inb<trows.size();inb++){
			
			
			List tCols = ((WebElement) trows.get(inb)).findElements(By.tagName("td"));
			
			System.out.println(inb);
						
			System.out.println(tCols.size());
			
			System.out.println(((WebElement) tCols.get(8)).getText());
			
			//System.out.println(((WebElement) tCols.get(22)).getText());
			
			for(int arr=0;arr<fR.sRQRID.length;arr++){
				
				if(((WebElement) tCols.get(8)).getText().equals(fR.sRQRID[arr])){
					
					fR.driver.findElement(By.xpath("/html/body/table[3]/tbody/tr/td[1]/table/tbody/tr/td/form/table[4]/tbody/tr/td/table[1]/tbody/tr["+x+"]/td[17]/input")).click();
					
					fR.KeywordGenerator("MQMButton","","CLICK","","");
					
					fR.KeywordGenerator("ForceRatesB","","CLICK","","");
					
				}
				
			}
					
			inb = inb+2;
			
			x = x+1;
			
		}
	}

}
