package com.modules;

import com.core.*;

public final class Login {
	
	public static void loginscenario() throws InterruptedException{
		
		System.out.println("Test Login");
		
		TestExecution tLogin = new TestExecution();
		String UserId = tLogin.GetData("UserId","LOGIN", 1);
		System.out.println(UserId);
		tLogin.KeywordGenerator("UserID","","SET",UserId,UserId);
		Thread.sleep(1000);
		tLogin.KeywordGenerator("Enter", "","CLICK","","");
		Thread.sleep(5000);
		tLogin.KeywordGenerator("Home","","VERIFYTEXT", "","Home");
		tLogin.KeywordGenerator("Queue","","VERIFYTEXT", "","Queue");
		tLogin.KeywordGenerator("Inbox","","VERIFYTEXT", "","Inbox");
		tLogin.KeywordGenerator("Reports","","VERIFYTEXT", "","Reports");
		tLogin.KeywordGenerator("SrhGroup","","VERIFYTEXT", "","Search Group");
		tLogin.KeywordGenerator("Reports","","VERIFYTEXT", "","Reports");
		tLogin.KeywordGenerator("Help","","VERIFYTEXT", "","Help");
		tLogin.KeywordGenerator("Logout","","VERIFYTEXT", "","Logout");
	}

}
