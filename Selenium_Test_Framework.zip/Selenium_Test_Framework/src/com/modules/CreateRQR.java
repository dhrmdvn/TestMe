package com.modules;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import jxl.Workbook;
import jxl.read.biff.BiffException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.core.*;

public class CreateRQR {
	static String addgroupurl = "http://xnzadwa3x.nndc.kp.org:9061/kp_webapp/sales/QuotePopulationAdd.do?.*";
	static String orghandler;
	static String sRQR;
	static int sRQRval = 0;
	static String oper;
	static Object cR;
	public static void sRQRCreation() throws InterruptedException{
		
		System.out.println("CreateRQR");
		
		TestExecution cR = new TestExecution();
		int sCount = cR.GETsTC_Count("CreateRQR");
		int sRowIDTC = cR.GetROWID("CreateRQR");
		cR.sRQRID = new String[sCount];
		String rqrsheet = "CreateRQR";
		String quotesheet = "CreateQuote";
		for(int iter = 0;iter<sCount;iter++){
			Thread.sleep(1000);			
			cR.KeywordGenerator("ProcessButton", "", "CLICK", "", "");
			cR.KeywordGenerator("Prospectlink","","VERIFYTEXT","","Prospect");
			cR.KeywordGenerator("Renewallink","","VERIFYTEXT","","Renewal");
			//RQR Type selected
			sRQR = cR.GetData("RQRType",rqrsheet, sRowIDTC);
			if (sRQR.equals("Prospect")){
				cR.KeywordGenerator("Prospectlink","","CLICK","","");
				sRQRval = 3;
			}
			else if(sRQR.equals("Renewal")){
				cR.KeywordGenerator("Renewallink","","CLICK","","");
				sRQRval = 2;
			}
			
			//Search Group
			
		//	cR.KeywordGenerator("VerifySrhgrp","","VERIFYTEXT","","Search Group");
			String GroupNum = cR.GetData("GroupNum",rqrsheet, sRowIDTC);
			cR.KeywordGenerator("Group_Num","","SET",GroupNum,GroupNum);
			
			String RatingRegion=cR.GetData("RatingRegion",rqrsheet, sRowIDTC);
			cR.KeywordGenerator("Rating_Rgns","","LIST",RatingRegion,RatingRegion);
						
			String Opportunityid = cR.GetData("Opportunityid",rqrsheet, sRowIDTC);
			cR.KeywordGenerator("OpportunityID","","SET",Opportunityid, Opportunityid);
			
			String AccountType =  cR.GetData("AccountType",rqrsheet, sRowIDTC);
			cR.KeywordGenerator("AccType","","LIST",AccountType,AccountType);
			
			String Group_Status = cR.GetData("Group_Status",rqrsheet, sRowIDTC);
			cR.KeywordGenerator("Group_Status","","LIST",Group_Status,Group_Status);
			
			String MarketSegment = cR.GetData("MarketSegment",rqrsheet,sRowIDTC);
			cR.KeywordGenerator("MarketSeg","","LIST",MarketSegment, MarketSegment);
			
			Thread.sleep(3000);
			
			if (sRQRval==2){
			cR.KeywordGenerator("SearchGroup","","CLICK","","");
			}else{
				cR.KeywordGenerator("pSearchGroup","","CLICK","","");
			}
			
			Thread.sleep(3000);
			cR.KeywordGenerator("sortEligibles","","CLICK","","");
			Thread.sleep(2000);
			oper = cR.GetData("Operval",rqrsheet,sRowIDTC);
			int rwd = operval(oper);
			cR.ClickTableprop(rwd);
			Thread.sleep(1000);
			cR.KeywordGenerator("NewRQR_button", "","CLICK","","");
			
			Thread.sleep(1000);
			
			String EffectiveDatefrm = cR.GetData("EffectiveDatefrm",rqrsheet,sRowIDTC);
			cR.KeywordGenerator("Eff_from","","SET",EffectiveDatefrm,EffectiveDatefrm);
			
			cR.driver.findElement(By.name("effectiveThrough")).click();
			Thread.sleep(1000);
			String Efftodate = cR.driver.findElement(By.name("effectiveThrough")).getText();
			
			System.out.println(Efftodate);
			
			if (Efftodate!=null){
				cR.KeywordGenerator("Eff_through","","CLEAR","","");
			}
			
			String EffectiveDatethrgh = cR.GetData("EffectiveDatethrgh",rqrsheet,sRowIDTC);
			cR.KeywordGenerator("Eff_through","","SET",EffectiveDatethrgh,EffectiveDatethrgh);
			
			//String EffectiveDate = cR.GetData("EffectiveDate",sRowIDTC);
			//cR.KeywordGenerator("RatingEff_date","","SET",EffectiveDate,EffectiveDate);
			cR.KeywordGenerator("TestRQR_Y", "", "SELECT", "", "");
			cR.KeywordGenerator("PostSalvald_Y", "", "SELECT", "", "");
			cR.KeywordGenerator("Rqr_save","","CLICK","","");
			Thread.sleep(1000);
			cR.KeywordGenerator("Rqr_Submit","","CLICK","","");
			try {
				Thread.sleep(1000);
				String strRQRID = cR.driver.findElement(By.xpath("/html/body/table[3]/tbody/tr/td[1]/form/table[4]/tbody/tr[1]/td[4]/div")).getText();
			    cR.sRQRID[sCount-1] = strRQRID;
				cR.KeywordGenerator("RqrID", "","GETTEXT","","");
				cR.WriteDatatoexcel("CreateRQR","RQRID",sRowIDTC,strRQRID);
				//updatequotesheet("CreateQuote","RQRID",sRowIDTC,strRQRID);
				cR.KeywordGenerator("Rqrstatus","","GETTEXT","","");
			} catch (InterruptedException e) {
				
				cR.error(e);
			}
			cR.KeywordGenerator("Rqrstatus","","GETTEXT","","");
			String RQRStatus = cR.driver.findElement(By.xpath("/html/body/table[3]/tbody/tr/td[1]/form/table[4]/tbody/tr[2]/td[4]/div")).getText();
			if(RQRStatus!="Initial Preperation"){
				cR.error("Status of RQR has not changed");
			}
			//Add Quote Creation Code.
			
			System.out.println("QuoteCreation");
			
			cR.KeywordGenerator("qmgmtlink","","CLICK","","");
			Thread.sleep(500);
			cR.KeywordGenerator("Quotepage","","VERIFYTEXT","","Quote Management");
			
			
			int sQCount = cR.GETCountwithFlag("CreateQuote",iter+1);
			
			int sQRowid = cR.GetROWId_Flag("CreateQuote",iter+1);
			
			int sid = sQRowid - (sQCount-1);
			
			for(int qt=0;qt<sQCount;qt++){
				
				cR.KeywordGenerator("NewQuote","", "CLICK","","");
				
				if(sRQR.equals("Prospect")){
					
					Thread.sleep(2000);
					String pQuoteName = cR.GetData("Quote_Name",quotesheet,sid );
					cR.KeywordGenerator("QuoteName","","SET",pQuoteName,pQuoteName);
					
					String pQuoteProd = cR.GetData("QuoteProduct",quotesheet,sid );
					cR.KeywordGenerator("QuoteProd","","LIST",pQuoteProd,pQuoteProd);
					
					Thread.sleep(1000);
					
					String pQuotePrdCat = cR.GetData("QuoteProductCategory",quotesheet,sid );
					cR.KeywordGenerator("QuotePrdCat","","LIST",pQuotePrdCat,pQuotePrdCat);
					
					Thread.sleep(1000);
				
					String pQuotePlan = cR.GetData("QuotePlan",quotesheet,sid );
					cR.KeywordGenerator("QuotePlan","","LIST",pQuotePlan,pQuotePlan);
					
					Thread.sleep(1000);
					
					cR.KeywordGenerator("QSave","","CLICK","","");
					
					Thread.sleep(1000);
				
					cR.KeywordGenerator("CensusTab", "", "CLICK","","");
					
					String pCensusType = cR.GetData("CensusType",quotesheet,sid);
					cR.KeywordGenerator("CensusType","","LIST",pCensusType,pCensusType);
					
					Thread.sleep(1000);
					
					String pCensusTstr = cR.GetData("CensusRateTier",quotesheet,sid);
					cR.KeywordGenerator("CensusTstr","","LIST",pCensusTstr,pCensusTstr);
					
					Thread.sleep(1000);
					
					cR.KeywordGenerator("CensusContinue", "", "CLICK","","");
					
					//String pBenefitDetails = qR.GetData("BPDetails", sid);
									
					Thread.sleep(5000);
					String Level19_M = cR.GetData("Level19_M",quotesheet,sid);
					
					String Level19_F = cR.GetData("Level19_F",quotesheet,sid);
					
					cR.driver.findElement(By.name("censusInfo(20,7_male)")).clear();
					
					cR.driver.findElement(By.name("censusInfo(20,7_male)")).sendKeys(Level19_M);
					cR.driver.findElement(By.name("censusInfo(20,7_female)")).clear();
					
					cR.driver.findElement(By.name("censusInfo(20,7_female)")).sendKeys(Level19_F);
					
				/*	String Level19_M = cR.GetData("Level19_M",quotesheet,sid);
					cR.KeywordGenerator("Male19","","SET",Level19_M,Level19_M);
					
					String Level19_F = cR.GetData("Level19_F",quotesheet,sid);
					cR.KeywordGenerator("Male19","","SET",Level19_F,Level19_F);*/
					
					String CenTotalNum = cR.GetData("CenTotalNum",quotesheet,sid);
					cR.KeywordGenerator("CenTotalNum","","SET",CenTotalNum,CenTotalNum);
										
					cR.KeywordGenerator("CalASF", "", "CLICK","","");
					
					Thread.sleep(8000);
					
					
					cR.KeywordGenerator("Benfittab","","CLICK","","");
					
					Thread.sleep(1000);
					
					cR.KeywordGenerator("BPDetails","","SELECT","","");
					
					String pBenefitPlan = cR.GetData("BenefitPlan",quotesheet,sid);
					cR.KeywordGenerator("BPlans","","LIST",pBenefitPlan,pBenefitPlan);
					
					
					Thread.sleep(2000);
					
					cR.KeywordGenerator("RateTier", "", "CLICK","","");
					
					//if needed we can included code to perform action on  Rate Tier, Objects are added.
					
					cR.KeywordGenerator("QSave","","CLICK","","");
					
					cR.KeywordGenerator("Rate", "", "CLICK","","");
					
					cR.driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
					
					cR.KeywordGenerator("QuoteSummary","","VERIFYTEXT","","Quote Rate Summary");
					
					cR.KeywordGenerator("QuoteID", "", "GETTEXT", "","");
					
					String pQuoteId = cR.driver.findElement(By.xpath("/html/body/table[3]/tbody/tr/td[1]/table[2]/tbody/tr[4]/td[2]")).getText();
					
					String [] qId = pQuoteId.split(":");
					
					cR.driver.manage().timeouts().pageLoadTimeout(30,TimeUnit.SECONDS);
					
					try{
						cR.KeywordGenerator("uwclink","","CLICK","","");
						Thread.sleep(1000);
						cR.driver.findElement(By.xpath("/html/body/table[3]/tbody/tr/td[1]/form/table/tbody/tr[2]/td[2]/table/tbody/tr[1]/td[3]/input")).sendKeys("\n");
						cR.info("DOWNLOADING UWC File");
						Thread.sleep(30000);
						Keystrokes();
						cR.driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
						if((checkfile(pQuoteName,qId[1].trim()))==true){
							cR.callPassDebug("Download","","UWC file","","UWC File Downloaded successfully and saved");
						}else{
							cR.callFailError("Download","","UWC FILE","","DOWNLOADING UWC", "File not exists");
						}
					}catch(Exception e){
						cR.debug("Error in File Download");
						cR.callFailError("Download","","UWC FILE","","DOWNLOADING UWC", "Download error"+e);
					}

				}else{
					String QuoteName = cR.GetData("Quote_Name",quotesheet,sid );
					cR.KeywordGenerator("QuoteName","","SET",QuoteName,QuoteName);
					
					String QuoteProd = cR.GetData("QuoteProduct",quotesheet,sid );
					cR.KeywordGenerator("QuoteProd","","LIST",QuoteProd,QuoteProd);
					
					String QuotePrdCat = cR.GetData("QuoteProductCategory",quotesheet,sid );
					cR.KeywordGenerator("QuoteProd","","LIST",QuotePrdCat,QuotePrdCat);
				
					String QuotePlan = cR.GetData("QuotePlan",quotesheet,sid );
					cR.KeywordGenerator("QuotePlan","","LIST",QuotePlan,QuotePlan);
					
					String STU = cR.GetData("STU",quotesheet,sid );
					cR.KeywordGenerator("STU","","LIST",STU,STU);
					
					String GC = cR.GetData("GC",quotesheet,sid );
					cR.KeywordGenerator("GC","","LIST",GC,GC);
											
					cR.KeywordGenerator("QSave","","CLICK","","");
					
					cR.KeywordGenerator("PopulationTab", "", "CLICK","","");
					
					orghandler = cR.driver.getWindowHandle();
					
					cR.KeywordGenerator("Addgroups", "", "CLICK","","");
					
					Thread.sleep(5000);
					
					Set <String> handlers = cR.driver.getWindowHandles();
					
					for(String handler : handlers){
						
						cR.driver.switchTo().window(handler);
						
						if(cR.driver.getCurrentUrl().matches(addgroupurl)){
							
							WebElement tbl = cR.driver.findElement(By.id("sg"));
							WebElement tb1 = tbl.findElement(By.tagName("tbody"));
							List rows = tb1.findElements(By.tagName("tr"));
							for(int tRow = 0;tRow<rows.size();tRow++){
								
								List Cols = ((WebElement) rows.get(tRow)).findElements(By.tagName("td"));
								
								if(((WebElement) Cols.get(7)).getText()!="--"){
									
									((WebElement) Cols.get(0)).click();
									
									break;
									
								}
								
							}
							
						}
						
					}
					
					cR.driver.switchTo().window(orghandler);
					
					Thread.sleep(5000);
					
					String pBenefitDetails = cR.GetData("BPDetails",quotesheet, sid);
					cR.KeywordGenerator("BPDetails","","SELECT",pBenefitDetails,pBenefitDetails);
					
					String BenefitPlan = cR.GetData("BenefitPlan",quotesheet,sid);
					cR.KeywordGenerator("BPlans","","LIST",BenefitPlan,BenefitPlan);
					
					Thread.sleep(3000);
					
					cR.KeywordGenerator("RateTier", "", "CLICK","","");
					
					//if needed we can included code to perform action on  Rate Tier, Objects are added.
					
					cR.KeywordGenerator("QSave","","CLICK","","");
					
					cR.KeywordGenerator("Rate", "", "CLICK","","");
					
					Thread.sleep(8000);
					
					cR.KeywordGenerator("QuoteSummary","","VERIFYTEXT","","Quote Rate Summary");
				
				}
				
			}
			
			
			
			sRowIDTC = sRowIDTC+1;
			Thread.sleep(2000);
		}
		
	cR = null;
	}
	
	private static void Keystrokes() {
		// TODO Auto-generated method stub
		Robot t;
		try {
			t = new Robot();
			t.keyPress(KeyEvent.VK_ALT);
			t.keyPress(KeyEvent.VK_S);
			t.keyRelease(KeyEvent.VK_ALT);
			t.keyRelease(KeyEvent.VK_S);
		} catch (AWTException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}

	public static int operval(String sValue){
		int oVal = 0;
		if(sValue.equals("View")){
			oVal = 1;
		}
		if (sValue.equals("Edit")){
			oVal = 2;
		}
		
		return oVal;
	}
	
	
	private static boolean checkfile(String filename,String fileId){

		Workbook uwb = null;
		
		File uwcworkbook;
		
		String uwcfilename;
		
		uwcfilename = filename+"("+fileId+")";
		System.out.println(uwcfilename);
		uwcworkbook = new File("C:\\Users\\h.soundrajan\\Desktop\\Selenium-works-WIP\\Selenium_Test_Framework\\src\\com\\testcase\\UWC\\"+uwcfilename+".xlsm");
		if(uwcworkbook.exists()){
			return true;
		}else{
			return false;
		}
	}

}
