package com.modules;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.core.*;

public final class SearchRQR {
	
	public static void TestMethods(){
		
		System.out.println("SearchRQR");
		
		TestExecution sR = new TestExecution();
		
		int strw = sR.GetROWID("SearchRQR");
		
		sR.KeywordGenerator("SearchRQR","","CLICK","","");
		
		String RatingRegions = sR.GetData("RatingRegions", "SearchRQR", strw);
		sR.KeywordGenerator("Rating_Rgns","","LIST","RatingRegions","RatingRegions");
		
		String RQRID = sR.GetData("RQRID","SearchRQR", strw);
		sR.KeywordGenerator("rqr_id","","SET","RQRID","RQRID");
		
		//SearchBROR
		
		sR.KeywordGenerator("SearchRQR","","CLICK","","");
		
		WebElement tbl = sR.driver.findElement(By.id("row"));
		WebElement tb1 = tbl.findElement(By.xpath("/html/body/table[3]/tbody/tr/td[1]/form/table[2]/tbody"));
		List rows1 = tb1.findElements(By.tagName("tr"));
		
		System.out.println(rows1.size());
		
		
	//	int x =1;
		for(int siter = 0;siter<rows1.size();siter++){
			
			
			List Cols = ((WebElement) rows1.get(siter)).findElements(By.tagName("td"));
			
			System.out.println(siter);
						
			System.out.println(Cols.size());
			
			System.out.println(((WebElement) Cols.get(8)).getText());
			
			if(((WebElement) Cols.get(8)).getText().equals(RQRID)){
				sR.callPassDebug("VerifyText","","RQRID",RQRID,"RQR is found in the search");
			}else{
				sR.callFailError("VerifyText","","RQRID",RQRID,"RQR is not found in the search", "Object not found");
			}
			
			//System.out.println(((WebElement) Cols.get(22)).getText());
			
			
		//	driver.findElement(By.xpath("/html/body/table[3]/tbody/tr/td[1]/table/tbody/tr/td/form/table[4]/tbody/tr/td/table[1]/tbody/tr["+x+"]/td[17]/input")).click();
			
			siter = siter+2;
			
		//	x = x+1;
			
		}
		
	}

}
