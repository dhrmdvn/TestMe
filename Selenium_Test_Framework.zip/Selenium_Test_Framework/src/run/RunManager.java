package run;

import com.core.TestExecution;

class RunManager extends TestExecution{

	public static void main(String[] args) {
	
	for (int i =0; i<1;i++){
		TestExecution t1 = new TestExecution();
		
		t1.startExecution();
	
		}
	}
	
}

